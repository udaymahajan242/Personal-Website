import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.TreeMap;

/**
 * 
 * @author : Uday Mahajan
 * 
 *         Paul G. Allen School of Computer Science & Engineering at University
 *         of Washington, Seattle (WA, U.S.A).
 * 
 *         Copyright © 2018 Uday Mahajan. All rights reserved.
 * 
 *         http://www.udaymahajan.me/
 * 
 *         No copying, distribution, or modification is permitted without prior
 *         written consent from the author.
 */

class ProcessClients {

	/*
	 * AUTHOR NOTES TO SELF:
	 * 
	 * Given : an array of Strings in format: <clientName> <timeStamp> (sorted by
	 * name and timestamp)
	 * 
	 * To Return: and array of Strings in format: <clientName> <numRequestsApproved>
	 * (sorted by name)
	 * 
	 * 1. Data to be split using String.split(" ");
	 * 
	 * 2. No more than rate limit requests should be added for a client in a
	 * particular minute interval i.e if a client as requested requests more than
	 * the given variable rateLimit, it should be ignored and not added into the
	 * variable(s) tracking the approved requests
	 * 
	 * 3. We need to keep track of the total number of approved requests across
	 * every client. If grand total is greater than or equal to 10 AND the client
	 * being processed has requested for more than 50% of those total number of
	 * approved requests in last 5 mins, then we need to block the client for next
	 * two minute intervals, ignoring all their requests. REMEMBER TO RESET THE
	 * TOTAL APPROVED COUNT TO 0 after 5 minute intervals
	 * 
	 * 4. Data Structures to be considered : Hashmaps, Lists, Queue, may be Queue.
	 * 
	 * 5. Possible Improvements : May be replace the mapping of interval number to
	 * Interval object by a list of Interval where the index represents the interval
	 * num. Need to consider the case where an index might be skipped resulting in
	 * null pointer exception in the later code.
	 * 
	 * CLASSES OR OBJECTS needed to be designed : Interval, ClientInformation.
	 * 
	 */

	public static class Interval {

		public int intervalNum; // The interval number ([n-1]th minute, eg 1st minute is interval 0)
		private int totalApproved; // total approved requests across all clients in this time Interval
		Map<String, List<Integer>> approvedRequests; // Maps Client names to the list of timestamps for which the
														// requests were approved.

		/*
		 * Constructs a NEW Interval object with given integer intervalNum.
		 */
		public Interval(int intervalNum) {
			this.intervalNum = intervalNum;
			this.totalApproved = 0;
			this.approvedRequests = new HashMap<String, List<Integer>>();
		}

		/*
		 * Returns true if this Interval contains the client with given String name,
		 * false otherwise.
		 */
		public boolean containsClient(String name) {
			return this.approvedRequests.containsKey(name);
		}

		/*
		 * Adds a new client with given String name.
		 */
		public void addNewClient(String name) {
			this.approvedRequests.put(name, new ArrayList<Integer>());
		}

		/* Returns a Set of clients in this Interval. */
		public Set<String> getClientNames() {
			return this.approvedRequests.keySet();
		}

		/*
		 * Returns a List of approved requests for given client name in this Interval.
		 */
		public List<Integer> getApprovedList(String name) {
			return this.approvedRequests.get(name);
		}

		/*
		 * Increases the total count of approved requests in this Interval by one.
		 */
		public void incrementTotal() {
			this.totalApproved++;
		}

		/*
		 * Returns a integer representing the total count of approved requests in this
		 * Interval
		 */
		public int getTotal() {
			return this.totalApproved;
		}

		/*
		 * Removes a client from this interval if it exits in this interval.
		 */
		public void removeClient(String client) {

			if (containsClient(client)) {
				this.approvedRequests.remove(client);
			}

		}

		/*
		 * Decrements the total count of approved requests in this Interval by given
		 * integer decrementBy.
		 */
		public void decrementTotalBy(int decrementBy) {
			this.totalApproved = this.totalApproved - decrementBy;
		}

	}

	/**
	 * 
	 * @author Uday Mahajan
	 *
	 *         Keeps track of relevant information for a client which requests the
	 *         server.
	 */
	private static class ClientInfo {

		public String name; // Name of the client.
		private int totalApprovedInLast5; // Number of requests approved for this client in last 5 minute intervals.
		private int totalApprovedSoFar; // Total number of requests that have been approved and not "blocked" for this
		// client.
		private int lastIntervalProcessed; // Keeps track of last interval in which client had requested.
		private Queue<Integer> numApprovedInEachLast5; // Keeps track of number of requests of this client
		// in each of previous 5 minutes

		/*
		 * Constructs a NEW Client object with given name.
		 */
		public ClientInfo(String name) {
			this.name = name;
			this.totalApprovedInLast5 = 0;
			this.totalApprovedSoFar = 0;
			this.lastIntervalProcessed = 0;
			this.numApprovedInEachLast5 = new LinkedList<Integer>();
		}

		/*
		 * Takes in an integer intervalNumber and an integer number of approved requests
		 * for this client in given intervalNumber.If intervalNumber is in the range of
		 * last 5 intervals processed, then we just increment the total number approved
		 * request in last five minutes of current client & add the number of requests
		 * in the queue keeping track of requests added in each last 5 intervals.
		 */
		public void updateLast5(int intervalNum, int sizeOfApprovedList) {

			// If current interval is not in the last 5 interval range then we need to
			// dequeue the first added in the queue and add the count of current one in this
			// interval (Slider approach.)

			if (isInLast5Range(intervalNum, this.lastIntervalProcessed)) {

				// If in the range of last 5, we just increment the
				// total approved in last 5 by adding total approved in this interval.
				// and also add it in the queue.

				this.numApprovedInEachLast5.offer(sizeOfApprovedList);
				this.totalApprovedInLast5 += sizeOfApprovedList;

			} else {
				// Current interval falls out of range of last 5 processed.

				// So, slide the window.
				int dequeued = this.numApprovedInEachLast5.poll();
				this.numApprovedInEachLast5.offer(sizeOfApprovedList);

				// Subtract the first one in last 5 and add the new one
				this.totalApprovedInLast5 -= dequeued;
				this.totalApprovedInLast5 += sizeOfApprovedList;

			}

			this.lastIntervalProcessed = intervalNum; // Update the last interval in which this client was seen

		}

		/*
		 * Increments the number of Total Approved Requests by given integer
		 * sizeOfApprovedList.
		 */
		public void incrementTotal(int sizeOfApprovedList) {
			this.totalApprovedSoFar += sizeOfApprovedList;
		}

	}

	/**
	 * Takes in a array requestLogs of log lines in the format <client> <timestamp>
	 * and an integer rateLimit.
	 * 
	 * Returns the array of Strings in the format <client> <numberRequestsAllowed>
	 * representing the number of requests allowed for that client.
	 **/
	public static String[] solution(String[] requestsLogs, int rateLimit) {

		Map<String, ClientInfo> clientsMap = new TreeMap<String, ClientInfo>(); // to keep clients sorted in natural
																				// order.

		Map<Integer, Interval> intervals = new HashMap<Integer, Interval>();

		for (String logLine : requestsLogs) {
			// Process the requestLogs array and get the name and time Stamp by splitting
			// each line of log.
			String[] token = logLine.split(" ");

			String name = token[0];
			int timeStamp = Integer.valueOf(token[1]);
			processClient(name, timeStamp, clientsMap, intervals, rateLimit); // takes care of blocking.

		}

		// At this point our intervals have processed the log lines while taking care of
		// the "blocking" the requests that cause overflow.

		// Now we go through the intervals and take care of the blacklisting client
		// requests while updating the approved requests, last5Minute interval data in
		// the map.

		approveClients(clientsMap, intervals);
		return getResult(clientsMap);

	}

	/*
	 * Takes in a String name representing the name of client to be processed,
	 * integer timeStamp representing when that client sent the request Collection
	 * mapping of Strings representing client names to client data ClientInfo, and a
	 * Collection mapping nth minute (n>=0) to interval data Interval and integer
	 * rateLimit provided.
	 * 
	 * Builds the given clientsMap and interval map based on client name and
	 * timestamp
	 */
	private static void processClient(String name, int timeStamp, Map<String, ClientInfo> clientsMap,
			Map<Integer, Interval> intervals, int rateLimit) {
		// Calculate the interval or minute to which this requests correspond to.
		int intervalNum = timeStamp / 60;

		// we index intervals as minute 0 (0s to 59s) & minute 1 (60s to 119s) and so
		// on..

		// if that interval minute does not exist in our list of intervals, add new one
		// to it.
		if (!intervals.containsKey(intervalNum)) {

			intervals.put(intervalNum, new Interval(intervalNum));

		}

		Interval currInterval = intervals.get(intervalNum);

		// if client does not exist in that interval"s map
		// create a client with an empty array list of approved requests for that client
		if (!currInterval.containsClient(name)) {
			currInterval.addNewClient(name);

		}

		// get the number of approved requests for current client in current interval
		// being processed.
		List<Integer> approvedRequests = currInterval.getApprovedList(name);

		// Take care of overflow.

		// if the number of approved requests for the current client is < rateLimit
		// approve the current request also.
		if (approvedRequests != null && approvedRequests.size() < rateLimit) {
			approvedRequests.add(timeStamp);
			currInterval.incrementTotal();
			// because we approved another request for a client in this minute.
		}

		// if the client does not exits in the client list, create a new ClientInfo for
		// that requestLine and add it to the list of ClientInfo

		if (!clientsMap.containsKey(name)) {
			ClientInfo newClient = new ClientInfo(name);
			clientsMap.put(name, newClient);

			/*
			 * System.out.println("Added client named " + name + " in clientInfo map");
			 * 
			 * System.out.println("Clients in clientInfoMap :-  " );
			 * System.out.println(clientsMap.keySet());
			 */

		}

	}

	/*
	 * Takes in a Collection mapping of Strings representing client names to client
	 * data ClientInfo "clientsMap", and a Collection mapping nth minute (n>=0) to
	 * interval data Interval "intervals".
	 * 
	 * Updates the number of approved requests in Client info of each client
	 * depending on if client needs to be blocked or not
	 */
	private static void approveClients(Map<String, ClientInfo> clientsMap, Map<Integer, Interval> intervals) {

		Queue<Integer> grandtotalInEachLast5 = new LinkedList<Integer>();
		int grandTotalAllowedInLast5 = 0; // total requests allowed in last 5 mins across all clients.
		int lastIntervalProcessed = 0; // last interval num processed.

		for (Interval interval : intervals.values()) {
			// go through each client and get list of approved request.

			int intervalNumber = interval.intervalNum;
			int totalAllowedICurrentInterval = interval.getTotal();

			// reset the grandtotal if needed

			if (!isInLast5Range(intervalNumber, lastIntervalProcessed)) {
				// current interval falls out of range of last 5 intervals processed.

				// slide the window.
				int dequeued = grandtotalInEachLast5.poll();
				grandtotalInEachLast5.offer(totalAllowedICurrentInterval);

				// Subtract the first one in last 5 and add the new one
				grandTotalAllowedInLast5 -= dequeued;
				grandTotalAllowedInLast5 += totalAllowedICurrentInterval;
			}

			// otherwise interval is in the range of last5 processed
			// so add the number of requests approved across all clients in that interval.
			grandTotalAllowedInLast5 += totalAllowedICurrentInterval;
			grandtotalInEachLast5.offer(totalAllowedICurrentInterval);

			// note blocking has been taken care of at this point and we need to figure if
			// the client needs to be blacklisted or not.

			// for each client in the interval, we get the list of approved requests.

			Set<String> allClientsInInterval = interval.getClientNames();

			for (String clientName : clientsMap.keySet()) {

				ClientInfo currClientInfo = clientsMap.get(clientName);

				if (!allClientsInInterval.contains(clientName)) { // this interval does not have this client
					// then update the last 5 in the client info.

					updateClientInfo(currClientInfo, intervalNumber, intervals, false);

				} else {// interval contains this client.

					// we also get the real time client info from our clients map above.

					// we want to update the last 5 count and the total approved so far upto and
					// including this interval
					// Note: if the client is a candidate for blacklisting, it will be blacklisted
					// in
					// next two intervals and not in this one.

					updateClientInfo(currClientInfo, intervalNumber, intervals, true);

					// see if client needs to be blacklisted for next two minutes.
					if (grandTotalAllowedInLast5 >= 10) { // numTotalApproved >=10 (1st condition for blacklisting)

						int last5CountForCurrClient = clientsMap.get(clientName).totalApprovedInLast5;

						if (last5CountForCurrClient > 0.5 * grandTotalAllowedInLast5) {

							// current client"s requests in last 5 minute intervals account for more than
							// 50% of the total requests approved so far.

							// So, blacklist the client for NEXT 2 minutes as required in the spec.
							blackList(clientName, intervalNumber, intervals);

						}

					}

				}
			}

		}

	}

	/*
	 * Takes in a collection mapping clientNames to ClientInfo and returns an array
	 * of Strings representing number of requests approved for each client in the
	 * given map in the format <clientName> <numberOfRequestsApproved>
	 */
	private static String[] getResult(Map<String, ClientInfo> clientsMap) {
		int resIndex = 0;
		int resSize = clientsMap.keySet().size();
		String[] result = new String[resSize];

		for (String client : clientsMap.keySet()) {

			int approvedRequests = clientsMap.get(client).totalApprovedSoFar;
			String toAdd = client + " " + approvedRequests;

			if (resIndex < resSize) {
				result[resIndex] = toAdd;
				resIndex++;
			}
		}

		return result;
	}

	/*
	 * Takes in a ClientInfo, integer currentInterval being processed, Mapping fo
	 * interval number to Interval object intervals and a boolean representing if
	 * the given client was seen in the given interval or not.
	 * 
	 * Updates the necessary client information in given ClientInfo.
	 */
	private static void updateClientInfo(ClientInfo currClientInfo, int currentInterval,
			Map<Integer, Interval> intervals, boolean isPresentInInterval) {

		int sizeOfApprovedList = 0;

		if (isPresentInInterval) { // interval contains the currentClient.

			// We update the number of requests approved for that client in the interval
			/// in out client Info stored in the map.
			Interval currInterval = intervals.get(currentInterval);
			sizeOfApprovedList = currInterval.getApprovedList(currClientInfo.name).size();

		}

		currClientInfo.incrementTotal(sizeOfApprovedList);

		// To check for blacklisting later in the solution function, we need to update
		// the
		// last 5 mins counts of the given client.
		currClientInfo.updateLast5(currentInterval, sizeOfApprovedList);

	}

	/*
	 * Takes in a string representing name of the client to blacklist, interger
	 * representing current interval number, and a map of interval numbers to
	 * Interval objects.
	 * 
	 * Black list a client for next two minutes.
	 */
	private static void blackList(String client, int currIntervalNum, Map<Integer, Interval> intervals) {

		// for next two intervals, we remove that client"s all requests in those
		// intervals.

		// We also update the totalApproved count in that interval yu subtracting the
		// number of requests that had previously been approved for that client
		// previously.

		int blockingStartInterval = currIntervalNum + 1;
		int interValsToBlockFor = 2;

		for (int i = blockingStartInterval; i < blockingStartInterval + interValsToBlockFor
				&& i < intervals.size(); i++) {

			Interval toBlockIn = intervals.get(i);

			if (toBlockIn.getApprovedList(client) != null) {

				int numRequestsToRemoved = toBlockIn.getApprovedList(client).size();

				toBlockIn.removeClient(client);
				toBlockIn.decrementTotalBy(numRequestsToRemoved);
			}

		}

	}

	/*
	 * Returns true if the given number is in the range of Last 5 intervals being
	 * processed, false if not.
	 */
	public static boolean isInLast5Range(int intervalNum, int lastIntervalProcessed) {
		int diff = intervalNum - lastIntervalProcessed;
		if (diff >= 0 && diff < 5) {
			return true;
		}
		return false;
	}

	/*
	 * CUSTOM TESTS @authors : Uday Mahajan & Codility.
	 * 
	 */
	public static void main(String[] args) {
		runTests();

	}

	public static void runTests() {
		System.out.println("STARTING TESTS.....");

		System.out.println();

		test0();
		test1();
		test2();
		test3();
		customTest();

		System.out.println("FINISHED TESTS FOR PROCESS CLIENTS.");
		System.out.println();
	}

	private static void test0() {

		final String[] requestLogs = { "bella 0", "bella 15", "bella 59", "bella 59", "bella 60", "bella 62",
				"bella 80", "bella 120", "bella 180", "bella 240", "erica 0", "erica 60", "erica 120", "erica 180",
				"erica 240", "erica 320" };
		final int rateLimit = 3;

		System.out.println("RUNNING TEST 0....");
		System.out.println();

		System.out.println("Request Logs: " + Arrays.toString(requestLogs));

		System.out.println("Rate Limit: " + rateLimit);

		String[] approved = solution(requestLogs, rateLimit);

		System.out.println();
		System.out.println("Number of Requests Approved: " + Arrays.toString(approved));
		System.out.println();
		System.out.println();

	}

	private static void test1() {
		final String[] requestLogs = { "java 0", "java 15", "java 59", "java 60", "java 120", "java 240", "python 0",
				"python 15", "python 45", "python 125" };
		final int rateLimit = 3;

		System.out.println("RUNNING TEST 1....");
		System.out.println();

		System.out.println("Request Logs: " + Arrays.toString(requestLogs));

		System.out.println("Rate Limit: " + rateLimit);

		String[] approved = solution(requestLogs, rateLimit);

		System.out.println();
		System.out.println("Number of Requests Approved: " + Arrays.toString(approved));
		System.out.println();
		System.out.println();

	}

	private static void test2() {
		final String[] requestLogs = { "blue 0", "blue 15", "blue 59", "blue 69", "blue 120", "blue 240", "red 0",
				"red 15", "red 45", "red 125" };
		final int rateLimit = 2;

		System.out.println("RUNNING TEST 2....");
		System.out.println();

		System.out.println("Request Logs: " + Arrays.toString(requestLogs));

		System.out.println("Rate Limit: " + rateLimit);

		String[] approved = solution(requestLogs, rateLimit);

		System.out.println();
		System.out.println("Number of Requests Approved: " + Arrays.toString(approved));
		System.out.println();
		System.out.println();

	}

	private static void test3() {

		final String[] requestLogs = { "client1 0", "client1 15", "client1 30", "client1 45", "client1 60",
				"client1 75", "client1 90", "client1 120", "client1 180", "client1 240", "client2 0", "client2 60",
				"client2 120", "client2 180", "client2 240", "client2 320" };
		final int rateLimit = 3;

		System.out.println("RUNNING TEST 3....");
		System.out.println();

		System.out.println("Request Logs: " + Arrays.toString(requestLogs));

		System.out.println("Rate Limit: " + rateLimit);

		String[] approved = solution(requestLogs, rateLimit);

		System.out.println();
		System.out.println("Number of Requests Approved: " + Arrays.toString(approved));
		System.out.println();
		System.out.println();

	}

	private static void customTest() {

		final String[] requestLogs = { "bella 0", "bella 2", "bella 60", "bella 80", "bella 110", "bella 245",
				"bella 350", "erica 0", "erica 50", "erica 62", "erica 68", "erica 120", "erica 135", "erica 240",
				"erica 280", "erica 299", "erica 335", "bill 7", "bill 8", "bill 9", "bill 10", "bill 200", "bill 240",
				"bill 280", "bill 295", "bill 320" };
		final int rateLimit = 3;

		System.out.println("RUNNING CUSTOM TEST ....");
		System.out.println();

		System.out.println("Request Logs: " + Arrays.toString(requestLogs));

		System.out.println("Rate Limit: " + rateLimit);

		String[] approved = solution(requestLogs, rateLimit);

		System.out.println();
		System.out.println("Number of Requests Approved: " + Arrays.toString(approved));
		System.out.println();
		System.out.println();

	}

}