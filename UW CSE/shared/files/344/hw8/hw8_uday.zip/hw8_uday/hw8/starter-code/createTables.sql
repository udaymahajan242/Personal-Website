-- add all your SQL setup statements here. 

-- You can assume that the following base table has been created with data loaded for you when we test your submission 
-- (you still need to create and populate it in your instance however),
-- although you are free to insert extra ALTER COLUMN ... statements to change the column 
-- names / types if you like.

--FLIGHTS (fid INT, 
--         month_id INT,        -- 1-12
--         day_of_month INT,    -- 1-31 
--         day_of_week_id INT,  -- 1-7, 1 = Monday, 2 = Tuesday, etc
--         carrier_id varchar(7), 
--         flight_num INT,
--         origin_city varchar(34), 
--         origin_state varchar(47), 
--         dest_city varchar(34), 
--         dest_state varchar(46), 
--         departure_delay INT, -- in mins
--         taxi_out INT,        -- in mins
--         arrival_delay INT,   -- in mins
--         canceled INT,        -- 1 means canceled
--         actual_time INT,     -- in mins
--         distance INT,        -- in miles
--         capacity INT, 
--         price INT            -- in $             
--         )

-- The customer information has following entities:
DROP TABLE IF EXISTS Users;
DROP TABLE IF EXISTS Reservations;
DROP TABLE IF EXISTS Itineraries;


-- Add a feild to FLIGHTS table to track booked seats.
ALTER TABLE FLIGHTS ADD reserved_capacity int NOT NULL DEFAULT(0);
ALTER TABLE FLIGHTS ADD CONSTRAINT CHECK_Capacity CHECK (reserved_capacity <= capacity);



-- CREATE Index on Flights table.
CREATE NONCLUSTERED INDEX nc_idx_flights_fid ON FLIGHTS 
(
	[fid] ASC
);

CREATE NONCLUSTERED INDEX nc_idx_flights_search ON FLIGHTS (
	day_of_month, origin_city, dest_city, canceled
);



-- 1. Customers: a customer has an cid (integer), a login, a password, a first name, a last name and non negative balance.

CREATE TABLE Users(
  username VARCHAR(20) PRIMARY KEY NOT NULL,
  password VARCHAR(20) NOT NULL,
  balance INT,
  CONSTRAINT CHECK_Customer_Balance CHECK (balance >= 0));
  
  
  
--2. Itenaries: Keeps track of direct and indirect iternaries.(I did not use it.)

  CREATE TABLE Itineraries (
  isDirect BIT NOT NULL DEFAULT(0),
  flight_id_1 INT NOT NULL,
  flight_id_2 INT NULL
  );
  
  --3. Reservations: Each reservation must include reservation id, username of the reserver,
  --  date of the flight, whether the reservation was paid, flight was can or not, price of the reservation.
  

CREATE TABLE Reservations
(
rid INT NOT NULL IDENTITY(1,1) PRIMARY KEY NONCLUSTERED,
username varchar(20),
date INT,
price INT,
is_paid INT NOT NULL DEFAULT(0),
flight_id_1 INT NOT NULL,
flight_id_2 INT NULL,
is_cancelled INT NOT NULL DEFAULT(0),
CONSTRAINT FK_Reserver_UserName FOREIGN KEY (username) REFERENCES Users(username),
CONSTRAINT FK_Reserved_FlightId1 FOREIGN KEY (flight_id_1) REFERENCES FLIGHTS (fid),
CONSTRAINT FK_Reserved_FlightId2 FOREIGN KEY (flight_id_2) REFERENCES FLIGHTS (fid),
CONSTRAINT CHECK_IsPaid CHECK (is_paid >= 0 AND is_paid <= 1),
CONSTRAINT CHECK_IsCancelled CHECK (is_cancelled >= 0 AND is_cancelled <= 1),
CONSTRAINT CHECK_User_Per_Day UNIQUE (username, date), 
CONSTRAINT CHECK_Reservation_Id CHECK (rid > 0)
);

CREATE NONCLUSTERED INDEX nc_idx_res_username_date ON RESERVATIONS (username, date);

CREATE CLUSTERED INDEX idx_res_username_rid ON RESERVATIONS (username, rid);


-- https://www.w3schools.com/sql/sql_view.asp



