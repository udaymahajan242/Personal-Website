
/*
 * Copyright © 2018 Uday Mahajan.  All rights reserved.  Permission is
 * hereby granted to course staff registered for University of Washington
 * CSE 344 for use solely during Summer Quarter 2018 for purposes of
 * the course.  No other use, copying, distribution, or modification
 * is permitted without prior written consent. Copyrights for
 * third-party components of this work must be honored.

 * Student: Uday Mahajan
 * SID : 1750102
 * UWNetID : udaym242
 * CSE 344 HW8 (Summer 2018).
*/

import java.io.FileInputStream;
import java.sql.*;
import java.util.*;

/**
 * Runs queries against a back-end database
 */
public class Query {
	private String configFilename;
	private Properties configProps = new Properties();

	private String jSQLDriver;
	private String jSQLUrl;
	private String jSQLUser;
	private String jSQLPassword;

	// DB Connection
	private Connection conn;

	// Logged In User
	private String username; // customer username is unique

	// Canned queries
	private static final String CHECK_FLIGHT_CAPACITY = "SELECT (capacity - reserved_seats) as capacity FROM Flights WHERE fid = ?";
	private PreparedStatement checkFlightCapacityStatement;

	private static final String DECREASE_FLIGHT_CAPACITY = "UPDATE Flights SET reserved_seats = reserved_seats + 1 "
			+ "WHERE fid = ?";
	private PreparedStatement decreaseFlightCapacityStatement;

	private static final String INCREASE_FLIGHT_CAPACITY = "UPDATE Flights SET reserved_seats = reserved_seats - 1 WHERE fid IN"
			+ "(SELECT flight_id_1 FROM Reservations WHERE rid = ? UNION SELECT flight_id_2 FROM Reservations WHERE rid = ? AND flight_id_2 IS NOT NULL)";
	private PreparedStatement increaseFlightCapacityStatement;

	private static final String CREATE_USER = "INSERT INTO Users VALUES (?, ?, ?)";
	private PreparedStatement createUserStatement;

	private static final String VALIDATE_USER = "SELECT COUNT(*) as count FROM Users WHERE username = ? AND password = ?";
	private PreparedStatement validateUserStatement;

	private static final String GET_DIRECT_FLIGHTS = "SELECT TOP (?) "
			+ "fid,day_of_month,carrier_id,flight_num,origin_city,dest_city,actual_time,capacity,price "
			+ "FROM Flights " + "WHERE origin_city = ? AND dest_city = ? AND day_of_month = ? " + "AND canceled = 0 "
			+ "ORDER BY actual_time ASC, fid ASC";
	private PreparedStatement getDirectFlightsStatement;

	private static final String GET_NONDIRECT_FLIGHTS = "SELECT TOP (?) "
			+ "A.fid as A_fid,A.day_of_month as A_day_of_month,"
			+ "A.carrier_id as A_carrier_id,A.flight_num as A_flight_num,A.origin_city as A_origin_city,"
			+ "A.dest_city as A_dest_city,A.actual_time as A_actual_time,A.capacity as A_capacity,A.price as A_price, "
			+ "B.fid as B_fid,B.day_of_month as B_day_of_month,"
			+ "B.carrier_id as B_carrier_id,B.flight_num as B_flight_num,B.origin_city as B_origin_city,"
			+ "B.dest_city as B_dest_city,B.actual_time as B_actual_time,B.capacity as B_capacity,B.price as B_price, "
			+ "A.actual_time + B.actual_time as total_time " + "FROM Flights A, Flights B "
			+ "WHERE A.origin_city = ? AND B.dest_city = ? AND A.day_of_month = ? AND A.day_of_month = B.day_of_month"
			+ " AND A.dest_city = B.origin_city AND A.canceled = 0 and B.canceled = 0 "
			+ "ORDER BY total_time ASC, A_fid ASC, B_fid ASC";
	private PreparedStatement getNonDirectFlightsStatement;

	private static final String BOOK_ITINERARY = "INSERT INTO Reservations (username, flight_id_1, flight_id_2, date, price) OUTPUT Inserted.rid VALUES (?, ?, ?, ?, ?)";
	private PreparedStatement bookItineraryStatement;

	private static final String GET_USER_BALANCE = "SELECT * FROM Users " + "WHERE username = ? ";
	private PreparedStatement getUserBalanceStatement;

	private static final String GET_USER_RESERVATIONS = "SELECT R.rid as rid, R.is_paid as is_paid,"
			+ "	R.date as date," + " R.price as price," + "	A.fid as A_fid," + " A.day_of_month AS A_day_of_month,"
			+ "	A.day_of_week_id as A_day_of_week_id," + " A.carrier_id as A_carrier_id,"
			+ "	A.flight_num as A_flight_num," + " A.origin_city as A_origin_city," + "	A.dest_city as A_dest_city,"
			+ "	A.actual_time as A_actual_time," + " A.distance as A_distance," + "	A.capacity as A_capacity,"
			+ "	A.price as A_price," + "	B.fid as B_fid," + " B.day_of_month AS B_day_of_month,"
			+ "	B.day_of_week_id as B_day_of_week_id," + " B.carrier_id as B_carrier_id,"
			+ "	B.flight_num as B_flight_num," + " B.origin_city as B_origin_city," + "	B.dest_city as B_dest_city,"
			+ "	B.actual_time as B_actual_time," + "	B.distance as B_distance," + "	B.capacity as B_capacity,"
			+ "	B.price as B_price" + "	FROM view_Reservations R" + " INNER JOIN Flights A ON R.flight_id_1 = A.fid"
			+ "	LEFT OUTER JOIN Flights B ON R.flight_id_2 = B.fid" + "	WHERE R.username = ?";
	private PreparedStatement getUserReservationsStatement;

	private static final String GET_USER_RESERVATION_ON_DATE = "SELECT COUNT(*) as count FROM Reservations "
			+ "WHERE username = ? AND date = ? ";
	private PreparedStatement getUserReservationOnDateStatement;

	private static final String GET_A_USER_RESERVATION = "SELECT * FROM Reservations "
			+ "WHERE username = ? AND rid = ? ";
	private PreparedStatement getAUserReservationStatement;

	private static final String RESERVATION_PAYMENT = "UPDATE Users SET balance = ? WHERE username = ?";
	private PreparedStatement reservationPaymentStatement;

	private static final String REFUND_USER = "UPDATE Users SET balance= balance + ? WHERE username = ?";
	private PreparedStatement refundUserStatement;

	private static final String UPDATE_CANCELLATION_STATUS = "UPDATE Reservations SET is_cancelled=1 WHERE rid = ?;";
	private PreparedStatement updateCancellationStatusStatement;

	private static final String UPDATE_PAID_STATUS = "UPDATE Reservations SET is_paid=1-is_paid WHERE rid = ?;";
	private PreparedStatement updatePaidStatusStatement;

	// clear Tables

	private static final String CLEAR_RESERVATIONS = "DELETE FROM Reservations";
	private PreparedStatement clearReservationsStatement;

	private static final String CLEAR_USERS = "DELETE FROM Users";
	private PreparedStatement clearUsersStatement;

	private static final String RESET_RESERVATION_IDS = "DBCC CHECKIDENT(\"Reservations\", RESEED, 0)";
	private PreparedStatement resetReservationIdsStatement;

	private static final String RESET_FLIGHT_CAPACITY = "UPDATE Flights SET reserved_seats = 0";
	private PreparedStatement resetFlightCapacityStatement;

	// transactions
	private static final String BEGIN_TRANSACTION_SQL = "SET TRANSACTION ISOLATION LEVEL SERIALIZABLE; BEGIN TRANSACTION;";
	private PreparedStatement beginTransactionStatement;

	private static final String COMMIT_SQL = "COMMIT TRANSACTION";
	private PreparedStatement commitTransactionStatement;

	private static final String ROLLBACK_SQL = "ROLLBACK TRANSACTION";
	private PreparedStatement rollbackTransactionStatement;

	// search
	private Itinerary[] searchResults;
	private int searchResultCount;

	class Itinerary {
		public Flight flight1;
		public Flight flight2;
		public boolean isDirect;

		public Itinerary(Flight f) {
			isDirect = true;
			flight1 = f;
			flight2 = null;
		}

		public Itinerary(Flight f1, Flight f2) {
			isDirect = false;
			flight1 = f1;
			flight2 = f2;
		}

		@Override
		public String toString() {
			int flightCount = isDirect ? 1 : 2;
			int flightTime = isDirect ? flight1.time : flight1.time + flight2.time;
			return flightCount + " flight(s), " + flightTime + " minutes\n" + flight1.toString() + "\n"
					+ (isDirect == false ? flight2.toString() + "\n" : "");
		}
	}

	class Flight {
		public int fid;
		public int dayOfMonth; // July 2015 Dataset.
		public String carrierId;
		public String flightNum;
		public String originCity;
		public String destCity;
		public int time;
		public int capacity;
		public int price;

		public Flight(int fid, int dayOfMonth, String carrierId, String flightNum, String originCity, String destCity,
				int time, int capacity, int price) {
			this.fid = fid;
			this.dayOfMonth = dayOfMonth;
			this.carrierId = carrierId;
			this.flightNum = flightNum;
			this.originCity = originCity;
			this.destCity = destCity;
			this.time = time;
			this.capacity = capacity;
			this.price = price;
		}

		// https://docs.oracle.com/javase/7/docs/api/java/sql/ResultSet.html

		// Prefix used for distinguishing non-direct flights.
		public Flight(ResultSet r, String prefix) throws SQLException {
			this.fid = r.getInt(prefix + "fid");
			this.dayOfMonth = r.getInt(prefix + "day_of_month");
			this.carrierId = r.getString(prefix + "carrier_id");
			this.flightNum = r.getString(prefix + "flight_num");
			this.originCity = r.getString(prefix + "origin_city");
			this.destCity = r.getString(prefix + "dest_city");
			this.time = r.getInt(prefix + "actual_time");
			this.capacity = r.getInt(prefix + "capacity");
			this.price = r.getInt(prefix + "price");
		}

		@Override
		public String toString() {
			return "ID: " + fid + " Day: " + dayOfMonth + " Carrier: " + carrierId + " Number: " + flightNum
					+ " Origin: " + originCity + " Dest: " + destCity + " Duration: " + time + " Capacity: " + capacity
					+ " Price: " + price;
		}

	}

	public Query(String configFilename) {
		this.configFilename = configFilename;
	}

	/* Connection code to SQL Azure. */
	public void openConnection() throws Exception {
		configProps.load(new FileInputStream(configFilename));

		jSQLDriver = configProps.getProperty("flightservice.jdbc_driver");
		jSQLUrl = configProps.getProperty("flightservice.url");
		jSQLUser = configProps.getProperty("flightservice.sqlazure_username");
		jSQLPassword = configProps.getProperty("flightservice.sqlazure_password");

		/* load jdbc drivers */
		Class.forName(jSQLDriver).newInstance();

		/* open connections to the flights database */
		conn = DriverManager.getConnection(jSQLUrl, // database
				jSQLUser, // user
				jSQLPassword); // password

		conn.setAutoCommit(true); // by default automatically commit after each statement

		/*
		 * You will also want to appropriately set the transaction's isolation level
		 * through: conn.setTransactionIsolation(...) See Connection class' JavaDoc for
		 * details.
		 */
	}

	public void closeConnection() throws Exception {
		conn.close();
	}

	// Prints out the message for log.
	private void log(String msg) {
		// System.out.println(msg + "\n");
	}

	// Logs exceptions.
	private void log(Exception e) {
		log(e.toString());
		log(e.getMessage());
		// e.printStackTrace(System.out);
	}

	/**
	 * Clear the data in any custom tables created. Do not drop any tables and do
	 * not clear the flights table. You should clear any tables you use to store
	 * reservations and reset the next reservation ID to be 1.
	 */
	public void clearTables() {

		try {
			// your code here
			clearReservationsStatement.clearParameters();
			clearReservationsStatement.executeUpdate();

			clearUsersStatement.clearParameters();
			clearUsersStatement.executeUpdate();

			resetReservationIdsStatement.clearParameters();
			resetReservationIdsStatement.executeUpdate();

			resetFlightCapacityStatement.clearParameters();
			resetFlightCapacityStatement.executeUpdate();
		} catch (Exception e) {
			log(e);
		}

		return;
	}

	/**
	 * prepare all the SQL statements in this method. "preparing" a statement is
	 * almost like compiling it. Note that the parameters (with ?) are still not
	 * filled in
	 */
	public void prepareStatements() throws Exception {
		beginTransactionStatement = conn.prepareStatement(BEGIN_TRANSACTION_SQL);
		commitTransactionStatement = conn.prepareStatement(COMMIT_SQL);
		rollbackTransactionStatement = conn.prepareStatement(ROLLBACK_SQL);

		/* add here more prepare statements for all the other queries you need */
		/* . . . . . . */

		checkFlightCapacityStatement = conn.prepareStatement(CHECK_FLIGHT_CAPACITY);
		decreaseFlightCapacityStatement = conn.prepareStatement(DECREASE_FLIGHT_CAPACITY);
		increaseFlightCapacityStatement = conn.prepareStatement(INCREASE_FLIGHT_CAPACITY);

		resetFlightCapacityStatement = conn.prepareStatement(RESET_FLIGHT_CAPACITY);
		clearReservationsStatement = conn.prepareStatement(CLEAR_RESERVATIONS);
		resetReservationIdsStatement = conn.prepareStatement(RESET_RESERVATION_IDS);
		clearUsersStatement = conn.prepareStatement(CLEAR_USERS);

		createUserStatement = conn.prepareStatement(CREATE_USER);
		validateUserStatement = conn.prepareStatement(VALIDATE_USER);

		getDirectFlightsStatement = conn.prepareStatement(GET_DIRECT_FLIGHTS);
		getNonDirectFlightsStatement = conn.prepareStatement(GET_NONDIRECT_FLIGHTS);

		bookItineraryStatement = conn.prepareStatement(BOOK_ITINERARY);

		getUserBalanceStatement = conn.prepareStatement(GET_USER_BALANCE);
		getUserReservationsStatement = conn.prepareStatement(GET_USER_RESERVATIONS);
		getUserReservationOnDateStatement = conn.prepareStatement(GET_USER_RESERVATION_ON_DATE);
		getAUserReservationStatement = conn.prepareStatement(GET_A_USER_RESERVATION);

		reservationPaymentStatement = conn.prepareStatement(RESERVATION_PAYMENT);
		refundUserStatement = conn.prepareStatement(REFUND_USER);
		updateCancellationStatusStatement = conn.prepareStatement(UPDATE_CANCELLATION_STATUS);
		updatePaidStatusStatement = conn.prepareStatement(UPDATE_PAID_STATUS);

	}

	/**
	 * Takes a user's username and password and attempts to log the user in.
	 *
	 * @param username
	 * @param password
	 *
	 * @return If someone has already logged in, then return "User already logged
	 *         in\n" For all other errors, return "Login failed\n".
	 *
	 *         Otherwise, return "Logged in as [username]\n".
	 */
	public String transaction_login(String username, String password) {
		try {
			if (this.username != null) {
				return "User already logged in\n";
			}

			// Set parameters and execute validate statement.
			validateUserStatement.clearParameters();
			validateUserStatement.setString(1, username);
			validateUserStatement.setString(2, password);

			ResultSet results = validateUserStatement.executeQuery();
			results.next();
			int count = results.getInt("count");
			results.close();

			if (count == 1) {
				this.username = username;
				this.searchResults = null;
				this.searchResultCount = 0;
				return "Logged in as " + username + "\n";
			}
		} catch (Exception e) {
			log(e);
			// e.printStackTrace(System.out);
			return "Login failed\n";
		}

		return "Login failed\n";
	}

	/**
	 * Implement the create user function.
	 *
	 * @param username   new user's username. User names are unique the system.
	 * @param password   new user's password.
	 * @param initAmount initial amount to deposit into the user's account, should
	 *                   be >= 0 (failure otherwise).
	 *
	 * @return either "Created user {@code username}\n" or "Failed to create user\n"
	 *         if failed.
	 */
	public String transaction_createCustomer(String username, String password, int initAmount) {
		try {
			createUserStatement.clearParameters();
			createUserStatement.setString(1, username);
			createUserStatement.setString(2, password);
			createUserStatement.setDouble(3, initAmount);
			createUserStatement.executeUpdate();
			return "Created user " + username + "\n";
		} catch (Exception e) {
			log(e);
			// e.printStackTrace(System.out);
			return "Failed to create user\n";
		}

	}

	/**
	 * Implement the search function.
	 *
	 * Searches for flights from the given origin city to the given destination
	 * city, on the given day of the month. If {@code directFlight} is true, it only
	 * searches for isDirect flights, otherwise is searches for isDirect flights and
	 * flights with two "hops." Only searches for up to the number of itineraries
	 * given by {@code numberOfItineraries}.
	 *
	 * The results are sorted based on total flight time.
	 *
	 * @param originCity
	 * @param destinationCity
	 * @param directFlight        if true, then only search for isDirect flights,
	 *                            otherwise include indirect flights as well
	 * @param dayOfMonth
	 * @param numberOfItineraries number of itineraries to return
	 *
	 * @return If no itineraries were found, return "No flights match your
	 *         selection\n". If an error occurs, then return "Failed to search\n".
	 *
	 *         Otherwise, the sorted itineraries printed in the following format:
	 *
	 *         Itinerary [itinerary number]: [number of flights] flight(s), [total
	 *         flight time] minutes\n [first flight in itinerary]\n ... [last flight
	 *         in itinerary]\n
	 *
	 *         Each flight should be printed using the same format as in the
	 *         {@code Flight} class. Itinerary numbers in each search should always
	 *         start from 0 and increase by 1.
	 *
	 * @see Flight#toString()
	 */
	public String transaction_search(String originCity, String destinationCity, boolean directFlight, int dayOfMonth,
			int numberOfItineraries) {

		// return transaction_search_unsafe(originCity, destinationCity, directFlight,
		// dayOfMonth, numberOfItineraries);

		String res = "";
		try {

			// First get direct (one hop) flights.
			getDirectFlightsStatement.clearParameters();
			getDirectFlightsStatement.setInt(1, numberOfItineraries);
			getDirectFlightsStatement.setString(2, originCity);
			getDirectFlightsStatement.setString(3, destinationCity);
			getDirectFlightsStatement.setInt(4, dayOfMonth);

			searchResults = new Itinerary[numberOfItineraries];
			int itineraryCount = 0;

			ResultSet resultsDF = getDirectFlightsStatement.executeQuery();

			while (resultsDF.next()) {
				searchResults[itineraryCount] = new Itinerary(new Flight(resultsDF, ""));
				itineraryCount++;
			}

			resultsDF.close();

			if (directFlight == false) {
				// Now find non-direct flights.

				getNonDirectFlightsStatement.clearParameters();
				getNonDirectFlightsStatement.setInt(1, numberOfItineraries - itineraryCount);
				getNonDirectFlightsStatement.setString(2, originCity);
				getNonDirectFlightsStatement.setString(3, destinationCity);
				getNonDirectFlightsStatement.setInt(4, dayOfMonth);

				ResultSet resultsNDF = getNonDirectFlightsStatement.executeQuery();

				while (resultsNDF.next()) {
					searchResults[itineraryCount] = new Itinerary(new Flight(resultsNDF, "A_"),
							new Flight(resultsNDF, "B_"));
					itineraryCount++;
				}

				resultsNDF.close();
			}

			if (itineraryCount == 0) {
				return "No flights match your selection\n";
			}

			for (int i = 0; i < itineraryCount; i++) {
				res += "Itinerary " + i + ": ";
				res += searchResults[i].toString();
			}

			searchResultCount = itineraryCount;

			return res;
		} catch (Exception e) {
			log(e);
			return "Failed to search\n";
		}

	}

	/**
	 * Same as {@code transaction_search} except that it only performs single hop
	 * search and do it in an unsafe manner.
	 *
	 * @param originCity
	 * @param destinationCity
	 * @param directFlight
	 * @param dayOfMonth
	 * @param numberOfItineraries
	 *
	 * @return The search results. Note that this implementation *does not conform*
	 *         to the format required by {@code transaction_search}.
	 */
	private String transaction_search_unsafe(String originCity, String destinationCity, boolean directFlight,
			int dayOfMonth, int numberOfItineraries) {
		StringBuffer sb = new StringBuffer();

		try {
			// one hop itineraries
			String unsafeSearchSQL = "SELECT TOP (" + numberOfItineraries
					+ ") day_of_month,carrier_id,flight_num,origin_city,dest_city,actual_time,capacity,price "
					+ "FROM Flights " + "WHERE origin_city = \'" + originCity + "\' AND dest_city = \'"
					+ destinationCity + "\' AND day_of_month =  " + dayOfMonth + " " + "ORDER BY actual_time ASC";

			Statement searchStatement = conn.createStatement();
			ResultSet oneHopResults = searchStatement.executeQuery(unsafeSearchSQL);

			while (oneHopResults.next()) {
				int result_dayOfMonth = oneHopResults.getInt("day_of_month");
				String result_carrierId = oneHopResults.getString("carrier_id");
				String result_flightNum = oneHopResults.getString("flight_num");
				String result_originCity = oneHopResults.getString("origin_city");
				String result_destCity = oneHopResults.getString("dest_city");
				int result_time = oneHopResults.getInt("actual_time");
				int result_capacity = oneHopResults.getInt("capacity");
				int result_price = oneHopResults.getInt("price");

				sb.append("Day: " + result_dayOfMonth + " Carrier: " + result_carrierId + " Number: " + result_flightNum
						+ " Origin: " + result_originCity + " Destination: " + result_destCity + " Duration: "
						+ result_time + " Capacity: " + result_capacity + " Price: " + result_price + "\n");
			}
			oneHopResults.close();
		} catch (SQLException e) {
			// e.printStackTrace();
		}

		return sb.toString();
	}

	/**
	 * Implements the book itinerary function.
	 *
	 * @param itineraryId ID of the itinerary to book. This must be one that is
	 *                    returned by search in the current session.
	 *
	 * @return If the user is not logged in, then return "Cannot book reservations,
	 *         not logged in\n". If try to book an itinerary with invalid ID, then
	 *         return "No such itinerary {@code itineraryId}\n". If the user already
	 *         has a reservation on the same day as the one that they are trying to
	 *         book now, then return "You cannot book two flights in the same
	 *         day\n". For all other errors, return "Booking failed\n".
	 *
	 *         And if booking succeeded, return "Booked flight(s), reservation ID:
	 *         [reservationId]\n" where reservationId is a unique number in the
	 *         reservation system that starts from 1 and increments by 1 each time a
	 *         successful reservation is made by any user in the system.
	 */
	public String transaction_book(int itineraryId) {
		if (username == null) {
			return "Cannot book reservations, not logged in\n";
		}

		if (searchResultCount <= itineraryId || itineraryId < 0) {
			return "No such itinerary " + itineraryId + "\n";
		}

		String errorMessage = "Booking failed\n";

		Itinerary itineraryToBook = searchResults[itineraryId];
		try {
			beginTransaction();

			int date = itineraryToBook.flight1.dayOfMonth;

			getUserReservationOnDateStatement.clearParameters();
			getUserReservationOnDateStatement.setString(1, username);
			getUserReservationOnDateStatement.setInt(2, date);

			ResultSet reservations = getUserReservationOnDateStatement.executeQuery();
			reservations.next();
			int count = reservations.getInt("count");
			reservations.close();

			if (count != 0) {
				rollbackTransaction();
				return "You cannot book two flights in the same day\n";
			}

			// Check capacity of flight 1.
			boolean hasCapacity = checkFlightCapacity(itineraryToBook.flight1.fid) > 0;

			// If the flight is non - direct, check 2nd flight capacity too.
			if (hasCapacity && itineraryToBook.isDirect == false) {
				hasCapacity = checkFlightCapacity(itineraryToBook.flight2.fid) > 0;
			}

			if (hasCapacity) {
				// update the capacities.

				decreaseFlightCapacity(itineraryToBook.flight1.fid);

				if (itineraryToBook.isDirect == false) {
					decreaseFlightCapacity(itineraryToBook.flight2.fid);
				}

				bookItineraryStatement.clearParameters();
				bookItineraryStatement.setString(1, username);
				bookItineraryStatement.setInt(2, itineraryToBook.flight1.fid);

				int totalPrice = itineraryToBook.flight1.price;

				if (itineraryToBook.isDirect) {
					bookItineraryStatement.setNull(3, Types.INTEGER);
				}

				else {
					totalPrice += itineraryToBook.flight2.price;
					bookItineraryStatement.setInt(3, itineraryToBook.flight2.fid);
				}

				int dateOfMonth = itineraryToBook.flight1.dayOfMonth;

				bookItineraryStatement.setInt(4, dateOfMonth);
				bookItineraryStatement.setInt(5, totalPrice);

				ResultSet reservationResult = bookItineraryStatement.executeQuery();

//					int rid = getReservationID(username, itineraryToBook.flight1.fid, itineraryToBook.flight2.fid,
//							date);
				reservationResult.next();
				int res_id = reservationResult.getInt("rid");

				reservationResult.close();

				commitTransaction();
				return "Booked flight(s), reservation ID: " + res_id + "\n";
			} else {
				log("Sorry, no more seats are available."); // Print custom message.
			}
		} catch (Exception e) {
			log(e);
			if (e.getMessage().contains("Violation of UNIQUE KEY constraint 'CHECK_User_Per_Day'."))
			// unique constraint is hit on reservation.
			{
				errorMessage = "You cannot book two flights in the same day\n";
			}
		}

		try {
			rollbackTransaction();
		} catch (Exception e) {
			log("Exception during rollback tran");
			log(e);
		}
		return errorMessage;

	}

	/**
	 * Implements the reservations function.
	 *
	 * @return If no user has logged in, then return "Cannot view reservations, not
	 *         logged in\n" If the user has no reservations, then return "No
	 *         reservations found\n" For all other errors, return "Failed to
	 *         retrieve reservations\n"
	 *
	 *         Otherwise return the reservations in the following format:
	 *
	 *         Reservation [reservation ID] paid: [true or false]:\n" [flight 1
	 *         under the reservation] [flight 2 under the reservation] Reservation
	 *         [reservation ID] paid: [true or false]:\n" [flight 1 under the
	 *         reservation] [flight 2 under the reservation] ...
	 *
	 *         Each flight should be printed using the same format as in the
	 *         {@code Flight} class.
	 *
	 * @see Flight#toString()
	 */
	public String transaction_reservations() {
		if (username == null) {
			return "Cannot view reservations, not logged in\n";
		}

		String errorMessage = "Failed to retrieve reservations\n";

		try {
			getUserReservationsStatement.clearParameters();
			getUserReservationsStatement.setString(1, username);
			ResultSet reservations = getUserReservationsStatement.executeQuery();

			String userReservations = "";
			int numReserved = 0;

			while (reservations.next()) {
				userReservations += "Reservation " + reservations.getInt("rid") + " paid: ";
				userReservations += reservations.getInt("is_paid") == 0 ? "false" : "true";
				userReservations += ":\n";
				userReservations += (new Flight(reservations, "A_")).toString();
				userReservations += "\n";
				if (reservations.getInt("B_fid") != 0) {
					userReservations += (new Flight(reservations, "B_")).toString();
					userReservations += "\n";
				}

				numReserved++;
			}

			if (numReserved == 0) {
				return "No reservations found\n";
			}

			return userReservations;
		} catch (Exception e) {
			log(e);
			// e.printStackTrace();
		}

		return errorMessage;
	}

	/**
	 * Implements the cancel operation.
	 *
	 * @param reservationId the reservation ID to cancel
	 *
	 * @return If no user has logged in, then return "Cannot cancel reservations,
	 *         not logged in\n" For all other errors, return "Failed to cancel
	 *         reservation [reservationId]\n"
	 *
	 *         If successful, return "Canceled reservation [reservationId]\n"
	 *
	 *         Even though a reservation has been canceled, its ID should not be
	 *         reused by the system.
	 */
	public String transaction_cancel(int reservationId) {
		// only implement this if you are interested in earning extra credit for the HW!

		if (username == null) {
			return "Cannot cancel reservations, not logged in\n";
		}

		String errorMessage = "Failed to cancel reservation " + reservationId + "\n";
		try {

			beginTransaction();

			getAUserReservationStatement.clearParameters();
			getAUserReservationStatement.setString(1, username);
			getAUserReservationStatement.setInt(2, reservationId);

			// get the reservation to cancel.
			ResultSet reservation = getAUserReservationStatement.executeQuery();

			if (!reservation.next())// reservation does not exist
			{
				reservation.close();
				rollbackTransaction();
				return errorMessage;
			}

			int refundAmount = 0;

			if (reservation.getInt("is_paid") == 1) {
				refundAmount = reservation.getInt("price");
			}

			if (reservation.getInt("is_cancelled") == 1) {
				return errorMessage;
			}
			reservation.close();

			

			followCancellationProcedure(reservationId, username, refundAmount);

			commitTransaction();

			return "Canceled reservation " + reservationId + "\n";

		} catch (Exception e) {
			log(e);
			 // e.printStackTrace();
		}

		try {
			rollbackTransaction();
		} catch (Exception e) {
			log(e);
			// e.printStackTrace();
		}

		return errorMessage;
	}

	/**
	 * Implements the pay function.
	 *
	 * @param reservationId the reservation to pay for.
	 *
	 * @return If no user has logged in, then return "Cannot pay, not logged in\n"
	 *         If the reservation is not found / not under the logged in user's
	 *         name, then return "Cannot find unpaid reservation [reservationId]
	 *         under user: [username]\n" If the user does not have enough money in
	 *         their account, then return "User has only [balance] in account but
	 *         itinerary costs [cost]\n" For all other errors, return "Failed to pay
	 *         for reservation [reservationId]\n"
	 *
	 *         If successful, return "Paid reservation: [reservationId] remaining
	 *         balance: [balance]\n" where [balance] is the remaining balance in the
	 *         user's account.
	 */
	public String transaction_pay(int reservationId) {
		if (username == null) {
			return "Cannot pay, not logged in\n";
		}

		String errorMessage = "Failed to pay for reservation " + reservationId + "\n";

		try {
			beginTransaction();
			getAUserReservationStatement.clearParameters();
			getAUserReservationStatement.setString(1, username);
			getAUserReservationStatement.setInt(2, reservationId);

			ResultSet reservation = getAUserReservationStatement.executeQuery();

			if (!reservation.next() || reservation.getInt("is_paid") != 0)
			// reservation does not exist or does not need any payment.
			{
				reservation.close();
				rollbackTransaction();
				return "Cannot find unpaid reservation " + reservationId + " under user: " + username + "\n";
			}

			int paymentAmount = reservation.getInt("price");
			reservation.close();

			getUserBalanceStatement.clearParameters();
			getUserBalanceStatement.setString(1, username);

			ResultSet userBalance = getUserBalanceStatement.executeQuery();

			userBalance.next();
			int balanceAmount = userBalance.getInt("balance");
			userBalance.close();

			if (balanceAmount < paymentAmount) // not enough balance
			{
				rollbackTransaction();
				return "User has only " + balanceAmount + " in account but itinerary costs " + paymentAmount + "\n";
			}

			int newBalance = balanceAmount - paymentAmount;

			int res = followPaymentProcedure(newBalance, username, reservationId);

			commitTransaction();
			return "Paid reservation: " + reservationId + " remaining balance: " + (newBalance) + "\n";
		}

		catch (Exception e) {
			log(e);
			// e.printStackTrace();
			if (e.getMessage().contains("The UPDATE statement conflicted with the CHECK constraint \"CK_Paid\"")) {
				errorMessage = "Cannot find unpaid reservation " + reservationId + " under user: " + username + "\n";
			}

		}

		try {
			rollbackTransaction();
		} catch (Exception ex) {
			log(ex);
			ex.printStackTrace();
		}

		return errorMessage;
	}

	/* some utility functions below */

	public void beginTransaction() throws SQLException {
		conn.setAutoCommit(false);
		beginTransactionStatement.executeUpdate();
	}

	public void commitTransaction() throws SQLException {
		commitTransactionStatement.executeUpdate();
		conn.setAutoCommit(true);
	}

	public void rollbackTransaction() throws SQLException {
		rollbackTransactionStatement.executeUpdate();
		conn.setAutoCommit(true);
	}

	/**
	 * Uses PreparedStatements to cancel the reservation by the user and update
	 * tables.
	 * 
	 * @return
	 */
	private int followCancellationProcedure(int rid, String username, int refundAmount) throws SQLException {

		// decrease the reserved seats by one.
		increaseFlightCapacityStatement.clearParameters();
		increaseFlightCapacityStatement.setInt(1, rid);
		increaseFlightCapacityStatement.setInt(2, rid);
		increaseFlightCapacityStatement.executeUpdate();

		// refund the amount.
		refundUserStatement.clearParameters();
		refundUserStatement.setDouble(1, refundAmount);
		refundUserStatement.setString(2, username);
		refundUserStatement.executeUpdate();

		// update cancellation status.
		updateCancellationStatusStatement.clearParameters();
		updateCancellationStatusStatement.setInt(1, rid);
		updateCancellationStatusStatement.executeUpdate();

		// mark the reservation paid. WAS NOT SURE ABOUT IF this should be updated or
		// not.
		// The user is refunded though as above.
//		updatePaidStatusStatement.clearParameters();
//		updatePaidStatusStatement.setInt(1, rid);
//		updatePaidStatusStatement.executeUpdate();

		return 1;
	}

	private int followPaymentProcedure(int balance, String username, int rid) throws SQLException {

		// process payment.
		reservationPaymentStatement.clearParameters();
		reservationPaymentStatement.setInt(1, balance);
		reservationPaymentStatement.setString(2, username);
		reservationPaymentStatement.executeUpdate();

		// mark the reservation paid.
		updatePaidStatusStatement.clearParameters();
		updatePaidStatusStatement.setInt(1, rid);
		updatePaidStatusStatement.executeUpdate();

		return 1;

	}

	// Decreases flight capacity by decreasing the booked capacity.
	private void decreaseFlightCapacity(int fid) throws SQLException {
		decreaseFlightCapacityStatement.clearParameters();
		decreaseFlightCapacityStatement.setInt(1, fid);
		decreaseFlightCapacityStatement.executeUpdate();
	}

	/**
	 * Shows an example of using PreparedStatements after setting arguments. You
	 * don't need to use this method if you don't want to.
	 */
	private int checkFlightCapacity(int fid) throws SQLException {
		checkFlightCapacityStatement.clearParameters();
		checkFlightCapacityStatement.setInt(1, fid);
		ResultSet results = checkFlightCapacityStatement.executeQuery();
		results.next();
		int capacity = results.getInt("capacity");
		results.close();

		return capacity;
	}
}