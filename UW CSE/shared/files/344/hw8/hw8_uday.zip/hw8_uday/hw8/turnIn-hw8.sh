#!/bin/bash

# Check there are no uncommitted changes.
(git status | grep -q modified:) && echo 'ERROR: There are uncommitted changes in your working directory. You can do "git status" to see them. Please commit or stash uncommitted changes before submitting' && exit 1

echo "Checking files"
if [ ! -f "submission/createTables.sql" ]; then
    echo "MISSING FILE: submission/createTables.sql"
    exit 1
fi
if [ ! -f "submission/Query.java" ]; then
    echo "MISSING FILE: submission/Query.java"
    exit 1
fi

HW=hw8

COMMIT=$(git log | head -n 1 |  cut -b 1-14)
if (git tag $HW 2>/dev/null)
then
    echo "Created tag '$HW' pointing to $COMMIT"
else
    git tag -d $HW && git tag $HW
    echo "Re-creating tag '$HW'... (now $COMMIT)"
fi

echo "Now syncing with origin..."
git push origin --mirror #--atomic
echo "Please verify in gitlab that your tag '$HW' matches what you expect."
