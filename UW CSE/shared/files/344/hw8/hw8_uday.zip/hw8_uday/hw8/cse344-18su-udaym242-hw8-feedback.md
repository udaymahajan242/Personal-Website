# CSE 344 Homework 8: Database Application and Transaction Management
## Feedback for udaym242

1. (5/6 points)  
   Comments: -1: Username and passwords should be case-sensitive. -0 We probably need to change the thing about altering the flights table, since I have to run each person's code and it makes it harder when the flights table gets changed between each one.

2. (54/80 points)  
   Comments: -26: Passed 28/54 tests. Problems with sorting both direct and indirect flights together, booking fails (can't pay for reservations, etc. if booking fails), booking essentially just fails, but everything else seems to be working properly

3. (14/14 points)  
   Comments: Good job! That's a lot of tests! -0 missing "Cannot view reservations, not logged in" and "No flights match your selection"

4. (6/10 points)  
   Comments: 3/7 tests passed, fails to cancel reservation and booking fails

## Total: 79 / 100

### Additional notes:  
Thank you for making this run. The amount of time I spent on trying to make people's code work is inane. Also, good job with the indexes! It makes it a lot faster!

